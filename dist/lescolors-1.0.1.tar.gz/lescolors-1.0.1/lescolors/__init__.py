from .colors import Color
